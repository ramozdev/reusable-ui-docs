import { cva } from "class-variance-authority";

import { cn } from "@/lib/cn";
import { ITEM } from "./defaults";

const item = cva(
  `relative
  flex
  select-none
  items-center
  rounded-md
  p-2
  outline-none
  md:py-1
  disabled:pointer-events-none
  data-[disabled]:opacity-50`,
  {
    variants: {
      color: {
        slate: cn(
          `text-slate-900
  dark:text-slate-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-slate-900
  data-[highlighted]:text-slate-100
  dark:data-[highlighted]:bg-slate-200
  dark:data-[highlighted]:text-slate-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-slate-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-slate-950`
        ),
        gray: cn(
          `text-gray-900
  dark:text-gray-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-gray-900
  data-[highlighted]:text-gray-100
  dark:data-[highlighted]:bg-gray-200
  dark:data-[highlighted]:text-gray-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-gray-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-gray-950`
        ),
        zinc: cn(
          `text-zinc-900
  dark:text-zinc-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-zinc-900
  data-[highlighted]:text-zinc-100
  dark:data-[highlighted]:bg-zinc-200
  dark:data-[highlighted]:text-zinc-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-zinc-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-zinc-950`
        ),
        neutral: cn(
          `text-neutral-900
  dark:text-neutral-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-neutral-900
  data-[highlighted]:text-neutral-100
  dark:data-[highlighted]:bg-neutral-200
  dark:data-[highlighted]:text-neutral-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-950`
        ),
        stone: cn(
          `text-stone-900
  dark:text-stone-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-stone-900
  data-[highlighted]:text-stone-100
  dark:data-[highlighted]:bg-stone-200
  dark:data-[highlighted]:text-stone-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-stone-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-stone-950`
        ),
        red: cn(
          `text-red-900
  dark:text-red-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-red-900
  data-[highlighted]:text-red-100
  dark:data-[highlighted]:bg-red-200
  dark:data-[highlighted]:text-red-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-red-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-red-950`
        ),
        orange: cn(
          `text-orange-900
  dark:text-orange-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-orange-900
  data-[highlighted]:text-orange-100
  dark:data-[highlighted]:bg-orange-200
  dark:data-[highlighted]:text-orange-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-orange-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-orange-950`
        ),
        amber: cn(
          `text-amber-900
  dark:text-amber-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-amber-900
  data-[highlighted]:text-amber-100
  dark:data-[highlighted]:bg-amber-200
  dark:data-[highlighted]:text-amber-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-amber-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-amber-950`
        ),
        yellow: cn(
          `text-yellow-900
  dark:text-yellow-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-yellow-900
  data-[highlighted]:text-yellow-100
  dark:data-[highlighted]:bg-yellow-200
  dark:data-[highlighted]:text-yellow-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-yellow-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-yellow-950`
        ),
        lime: cn(
          `text-lime-900
  dark:text-lime-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-lime-900
  data-[highlighted]:text-lime-100
  dark:data-[highlighted]:bg-lime-200
  dark:data-[highlighted]:text-lime-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-lime-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-lime-950`
        ),
        green: cn(
          `text-green-900
  dark:text-green-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-green-900
  data-[highlighted]:text-green-100
  dark:data-[highlighted]:bg-green-200
  dark:data-[highlighted]:text-green-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-green-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-green-950`
        ),
        emerald: cn(
          `text-emerald-900
  dark:text-emerald-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-emerald-900
  data-[highlighted]:text-emerald-100
  dark:data-[highlighted]:bg-emerald-200
  dark:data-[highlighted]:text-emerald-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-emerald-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-emerald-950`
        ),
        teal: cn(
          `text-teal-900
  dark:text-teal-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-teal-900
  data-[highlighted]:text-teal-100
  dark:data-[highlighted]:bg-teal-200
  dark:data-[highlighted]:text-teal-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-teal-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-teal-950`
        ),
        cyan: cn(
          `text-cyan-900
  dark:text-cyan-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-cyan-900
  data-[highlighted]:text-cyan-100
  dark:data-[highlighted]:bg-cyan-200
  dark:data-[highlighted]:text-cyan-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-cyan-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-cyan-950`
        ),
        sky: cn(
          `text-sky-900
  dark:text-sky-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-sky-900
  data-[highlighted]:text-sky-100
  dark:data-[highlighted]:bg-sky-200
  dark:data-[highlighted]:text-sky-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-sky-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-sky-950`
        ),
        blue: cn(
          `text-blue-900
  dark:text-blue-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-blue-900
  data-[highlighted]:text-blue-100
  dark:data-[highlighted]:bg-blue-200
  dark:data-[highlighted]:text-blue-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-blue-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-blue-950`
        ),
        indigo: cn(
          `text-indigo-900
  dark:text-indigo-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-indigo-900
  data-[highlighted]:text-indigo-100
  dark:data-[highlighted]:bg-indigo-200
  dark:data-[highlighted]:text-indigo-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-indigo-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-indigo-950`
        ),
        violet: cn(
          `text-violet-900
  dark:text-violet-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-violet-900
  data-[highlighted]:text-violet-100
  dark:data-[highlighted]:bg-violet-200
  dark:data-[highlighted]:text-violet-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-violet-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-violet-950`
        ),
        purple: cn(
          `text-purple-900
  dark:text-purple-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-purple-900
  data-[highlighted]:text-purple-100
  dark:data-[highlighted]:bg-purple-200
  dark:data-[highlighted]:text-purple-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-purple-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-purple-950`
        ),
        fuchsia: cn(
          `text-fuchsia-900
  dark:text-fuchsia-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-fuchsia-900
  data-[highlighted]:text-fuchsia-100
  dark:data-[highlighted]:bg-fuchsia-200
  dark:data-[highlighted]:text-fuchsia-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-fuchsia-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-fuchsia-950`
        ),
        pink: cn(
          `text-pink-900
  dark:text-pink-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-pink-900
  data-[highlighted]:text-pink-100
  dark:data-[highlighted]:bg-pink-200
  dark:data-[highlighted]:text-pink-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-pink-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-pink-950`
        ),
        rose: cn(
          `text-rose-900
  dark:text-rose-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-rose-900
  data-[highlighted]:text-rose-100
  dark:data-[highlighted]:bg-rose-200
  dark:data-[highlighted]:text-rose-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-rose-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-rose-950`
        ),
        "white-black": cn(
          `text-neutral-900
  dark:text-neutral-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-neutral-900
  data-[highlighted]:text-neutral-100
  dark:data-[highlighted]:bg-neutral-200
  dark:data-[highlighted]:text-neutral-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-950`
        ),
        "black-white": cn(
          `text-neutral-900
  dark:text-neutral-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-neutral-900
  data-[highlighted]:text-neutral-100
  dark:data-[highlighted]:bg-neutral-200
  dark:data-[highlighted]:text-neutral-950`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-950`
        ),
      },
    },
    defaultVariants: {
      color: ITEM,
    },
  }
);

export { item };
