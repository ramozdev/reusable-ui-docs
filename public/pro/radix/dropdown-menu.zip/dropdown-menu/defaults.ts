import { type Colors } from "@/lib/colors";

const ITEM: Colors = "blue";
const SUB_TRIGGER: Colors = "blue";
const RIGHT_SLOT: Colors = "blue";

const TRIGGER: Colors = "blue";

const CONTENT: Colors = "neutral";
const SEPARATOR: Colors = "neutral";
const LABEL: Colors = "neutral";
const ARROW: Colors = "neutral";

const CONTENT_SIDE_OFFSET = 5;

const SUB_CONTENT_SIDE_OFFSET = 2;
const SUB_CONTENT_ALIGN_OFFSET = -9;

export {
  ITEM,
  CONTENT,
  SEPARATOR,
  LABEL,
  ARROW,
  SUB_TRIGGER,
  RIGHT_SLOT,
  TRIGGER,
  CONTENT_SIDE_OFFSET,
  SUB_CONTENT_SIDE_OFFSET,
  SUB_CONTENT_ALIGN_OFFSET,
};
