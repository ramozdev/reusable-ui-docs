import { cva } from "class-variance-authority";

import { cn } from "@/lib/cn";
import { CONTENT } from "./defaults";

const content = cva(
  `z-50
    p-2
    border
    rounded-md
    shadow-sm
    min-w-[220px]
    data-[side=top]:animate-slideDownAndFade
    data-[side=right]:animate-slideLeftAndFade
    data-[side=bottom]:animate-slideUpAndFade
    data-[side=left]:animate-slideRightAndFade`,
  {
    variants: {
      color: {
        slate: cn(
          `bg-slate-50
        border-slate-400
        dark:bg-slate-950
        dark:border-slate-700`
        ),
        gray: cn(
          `bg-gray-50
        border-gray-400
        dark:bg-gray-950
        dark:border-gray-700`
        ),
        zinc: cn(
          `bg-zinc-50
        border-zinc-400
        dark:bg-zinc-950
        dark:border-zinc-700`
        ),
        neutral: cn(
          `bg-neutral-50
        border-neutral-400
        dark:bg-neutral-950
        dark:border-neutral-700`
        ),
        stone: cn(
          `bg-stone-50
        border-stone-400
        dark:bg-stone-950
        dark:border-stone-700`
        ),
        red: cn(
          `bg-red-50
        border-red-400
        dark:bg-red-950
        dark:border-red-700`
        ),
        orange: cn(
          `bg-orange-50
        border-orange-400
        dark:bg-orange-950
        dark:border-orange-700`
        ),
        amber: cn(
          `bg-amber-50
        border-amber-400
        dark:bg-amber-950
        dark:border-amber-700`
        ),
        yellow: cn(
          `bg-yellow-50
        border-yellow-400
        dark:bg-yellow-950
        dark:border-yellow-700`
        ),
        lime: cn(
          `bg-lime-50
        border-lime-400
        dark:bg-lime-950
        dark:border-lime-700`
        ),
        green: cn(
          `bg-green-50
        border-green-400
        dark:bg-green-950
        dark:border-green-700`
        ),
        emerald: cn(
          `bg-emerald-50
        border-emerald-400
        dark:bg-emerald-950
        dark:border-emerald-700`
        ),
        teal: cn(
          `bg-teal-50
        border-teal-400
        dark:bg-teal-950
        dark:border-teal-700`
        ),
        cyan: cn(
          `bg-cyan-50
        border-cyan-400
        dark:bg-cyan-950
        dark:border-cyan-700`
        ),
        sky: cn(
          `bg-sky-50
        border-sky-400
        dark:bg-sky-950
        dark:border-sky-700`
        ),
        blue: cn(
          `bg-blue-50
        border-blue-400
        dark:bg-blue-950
        dark:border-blue-700`
        ),
        indigo: cn(
          `bg-indigo-50
        border-indigo-400
        dark:bg-indigo-950
        dark:border-indigo-700`
        ),
        violet: cn(
          `bg-violet-50
        border-violet-400
        dark:bg-violet-950
        dark:border-violet-700`
        ),
        purple: cn(
          `bg-purple-50
        border-purple-400
        dark:bg-purple-950
        dark:border-purple-700`
        ),
        fuchsia: cn(
          `bg-fuchsia-50
        border-fuchsia-400
        dark:bg-fuchsia-950
        dark:border-fuchsia-700`
        ),
        pink: cn(
          `bg-pink-50
        border-pink-400
        dark:bg-pink-950
        dark:border-pink-700`
        ),
        rose: cn(
          `bg-rose-50
        border-rose-400
        dark:bg-rose-950
        dark:border-rose-700`
        ),
        "white-black": cn(
          `bg-white
        border-black
        dark:bg-black
        dark:border-white`
        ),
        "black-white": cn(
          `bg-black
        border-white
        dark:bg-white
        dark:border-black`
        ),
      },
    },
    defaultVariants: {
      color: CONTENT,
    },
  }
);

export { content };
