import { cva } from "class-variance-authority";

import { cn } from "@/lib/cn";
import { SEPARATOR } from "./defaults";

const separator = cva(
  `my-1.5
  h-px`,
  {
    variants: {
      color: {
        slate: cn(
          `bg-slate-300
            dark:bg-slate-800`
        ),
        gray: cn(
          `bg-gray-300
            dark:bg-gray-800`
        ),
        zinc: cn(
          `bg-zinc-300
            dark:bg-zinc-800`
        ),
        neutral: cn(
          `bg-neutral-300
            dark:bg-neutral-800`
        ),
        stone: cn(
          `bg-stone-300
            dark:bg-stone-800`
        ),
        red: cn(
          `bg-red-300
            dark:bg-red-800`
        ),
        orange: cn(
          `bg-orange-300
            dark:bg-orange-800`
        ),
        amber: cn(
          `bg-amber-300
            dark:bg-amber-800`
        ),
        yellow: cn(
          `bg-yellow-300
            dark:bg-yellow-800`
        ),
        lime: cn(
          `bg-lime-300
            dark:bg-lime-800`
        ),
        green: cn(
          `bg-green-300
            dark:bg-green-800`
        ),
        emerald: cn(
          `bg-emerald-300
            dark:bg-emerald-800`
        ),
        teal: cn(
          `bg-teal-300
            dark:bg-teal-800`
        ),
        cyan: cn(
          `bg-cyan-300
            dark:bg-cyan-800`
        ),
        sky: cn(
          `bg-sky-300
            dark:bg-sky-800`
        ),
        blue: cn(
          `bg-blue-300
            dark:bg-blue-800`
        ),
        indigo: cn(
          `bg-indigo-300
            dark:bg-indigo-800`
        ),
        violet: cn(
          `bg-violet-300
            dark:bg-violet-800`
        ),
        purple: cn(
          `bg-purple-300
            dark:bg-purple-800`
        ),
        fuchsia: cn(
          `bg-fuchsia-300
            dark:bg-fuchsia-800`
        ),
        pink: cn(
          `bg-pink-300
            dark:bg-pink-800`
        ),
        rose: cn(
          `bg-rose-300
            dark:bg-rose-800`
        ),
        "white-black": cn(
          `bg-black/40
            dark:bg-white/40`
        ),
        "black-white": cn(
          `bg-white/40
            dark:bg-black/40`
        ),
      },
    },
    defaultVariants: {
      color: SEPARATOR,
    },
  }
);

export { separator };
