import { cva } from "class-variance-authority";

import { cn } from "@/lib/cn";
import { SUB_TRIGGER } from "./defaults";

const subTrigger = cva(
  `relative
    flex
    select-none
    items-center
    rounded-md
    p-2
    outline-none
    md:py-1
    disabled:pointer-events-none
    data-[disabled]:opacity-50`,
  {
    variants: {
      color: {
        slate: cn(
          `text-slate-900
  dark:text-slate-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-slate-900
  data-[highlighted]:text-slate-100
  dark:data-[highlighted]:bg-slate-200 
  dark:data-[highlighted]:text-slate-950`,

          `data-[highlighted]:data-[state=open]:bg-slate-900
  data-[highlighted]:data-[state=open]:text-slate-100
  dark:data-[highlighted]:data-[state=open]:bg-slate-200
  dark:data-[highlighted]:data-[state=open]:text-slate-950`,

          // OPEN
          `data-[state=open]:bg-slate-200
  data-[state=open]:text-slate-950
  dark:data-[state=open]:bg-slate-800
  dark:data-[state=open]:text-slate-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-slate-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-slate-950`
        ),
        gray: cn(
          `text-gray-900
  dark:text-gray-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-gray-900
  data-[highlighted]:text-gray-100
  dark:data-[highlighted]:bg-gray-200 
  dark:data-[highlighted]:text-gray-950`,

          `data-[highlighted]:data-[state=open]:bg-gray-900
  data-[highlighted]:data-[state=open]:text-gray-100
  dark:data-[highlighted]:data-[state=open]:bg-gray-200
  dark:data-[highlighted]:data-[state=open]:text-gray-950`,

          // OPEN
          `data-[state=open]:bg-gray-200
  data-[state=open]:text-gray-950
  dark:data-[state=open]:bg-gray-800
  dark:data-[state=open]:text-gray-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-gray-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-gray-950`
        ),
        zinc: cn(
          `text-zinc-900
  dark:text-zinc-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-zinc-900
  data-[highlighted]:text-zinc-100
  dark:data-[highlighted]:bg-zinc-200 
  dark:data-[highlighted]:text-zinc-950`,

          `data-[highlighted]:data-[state=open]:bg-zinc-900
  data-[highlighted]:data-[state=open]:text-zinc-100
  dark:data-[highlighted]:data-[state=open]:bg-zinc-200
  dark:data-[highlighted]:data-[state=open]:text-zinc-950`,

          // OPEN
          `data-[state=open]:bg-zinc-200
  data-[state=open]:text-zinc-950
  dark:data-[state=open]:bg-zinc-800
  dark:data-[state=open]:text-zinc-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-zinc-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-zinc-950`
        ),
        neutral: cn(
          `text-neutral-900
  dark:text-neutral-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-neutral-900
  data-[highlighted]:text-neutral-100
  dark:data-[highlighted]:bg-neutral-200 
  dark:data-[highlighted]:text-neutral-950`,

          `data-[highlighted]:data-[state=open]:bg-neutral-900
  data-[highlighted]:data-[state=open]:text-neutral-100
  dark:data-[highlighted]:data-[state=open]:bg-neutral-200
  dark:data-[highlighted]:data-[state=open]:text-neutral-950`,

          // OPEN
          `data-[state=open]:bg-neutral-200
  data-[state=open]:text-neutral-950
  dark:data-[state=open]:bg-neutral-800
  dark:data-[state=open]:text-neutral-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-950`
        ),
        stone: cn(
          `text-stone-900
  dark:text-stone-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-stone-900
  data-[highlighted]:text-stone-100
  dark:data-[highlighted]:bg-stone-200 
  dark:data-[highlighted]:text-stone-950`,

          `data-[highlighted]:data-[state=open]:bg-stone-900
  data-[highlighted]:data-[state=open]:text-stone-100
  dark:data-[highlighted]:data-[state=open]:bg-stone-200
  dark:data-[highlighted]:data-[state=open]:text-stone-950`,

          // OPEN
          `data-[state=open]:bg-stone-200
  data-[state=open]:text-stone-950
  dark:data-[state=open]:bg-stone-800
  dark:data-[state=open]:text-stone-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-stone-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-stone-950`
        ),
        red: cn(
          `text-red-900
  dark:text-red-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-red-900
  data-[highlighted]:text-red-100
  dark:data-[highlighted]:bg-red-200 
  dark:data-[highlighted]:text-red-950`,

          `data-[highlighted]:data-[state=open]:bg-red-900
  data-[highlighted]:data-[state=open]:text-red-100
  dark:data-[highlighted]:data-[state=open]:bg-red-200
  dark:data-[highlighted]:data-[state=open]:text-red-950`,

          // OPEN
          `data-[state=open]:bg-red-200
  data-[state=open]:text-red-950
  dark:data-[state=open]:bg-red-800
  dark:data-[state=open]:text-red-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-red-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-red-950`
        ),
        orange: cn(
          `text-orange-900
  dark:text-orange-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-orange-900
  data-[highlighted]:text-orange-100
  dark:data-[highlighted]:bg-orange-200 
  dark:data-[highlighted]:text-orange-950`,

          `data-[highlighted]:data-[state=open]:bg-orange-900
  data-[highlighted]:data-[state=open]:text-orange-100
  dark:data-[highlighted]:data-[state=open]:bg-orange-200
  dark:data-[highlighted]:data-[state=open]:text-orange-950`,

          // OPEN
          `data-[state=open]:bg-orange-200
  data-[state=open]:text-orange-950
  dark:data-[state=open]:bg-orange-800
  dark:data-[state=open]:text-orange-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-orange-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-orange-950`
        ),
        amber: cn(
          `text-amber-900
  dark:text-amber-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-amber-900
  data-[highlighted]:text-amber-100
  dark:data-[highlighted]:bg-amber-200 
  dark:data-[highlighted]:text-amber-950`,

          `data-[highlighted]:data-[state=open]:bg-amber-900
  data-[highlighted]:data-[state=open]:text-amber-100
  dark:data-[highlighted]:data-[state=open]:bg-amber-200
  dark:data-[highlighted]:data-[state=open]:text-amber-950`,

          // OPEN
          `data-[state=open]:bg-amber-200
  data-[state=open]:text-amber-950
  dark:data-[state=open]:bg-amber-800
  dark:data-[state=open]:text-amber-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-amber-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-amber-950`
        ),
        yellow: cn(
          `text-yellow-900
  dark:text-yellow-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-yellow-900
  data-[highlighted]:text-yellow-100
  dark:data-[highlighted]:bg-yellow-200 
  dark:data-[highlighted]:text-yellow-950`,

          `data-[highlighted]:data-[state=open]:bg-yellow-900
  data-[highlighted]:data-[state=open]:text-yellow-100
  dark:data-[highlighted]:data-[state=open]:bg-yellow-200
  dark:data-[highlighted]:data-[state=open]:text-yellow-950`,

          // OPEN
          `data-[state=open]:bg-yellow-200
  data-[state=open]:text-yellow-950
  dark:data-[state=open]:bg-yellow-800
  dark:data-[state=open]:text-yellow-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-yellow-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-yellow-950`
        ),
        lime: cn(
          `text-lime-900
  dark:text-lime-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-lime-900
  data-[highlighted]:text-lime-100
  dark:data-[highlighted]:bg-lime-200 
  dark:data-[highlighted]:text-lime-950`,

          `data-[highlighted]:data-[state=open]:bg-lime-900
  data-[highlighted]:data-[state=open]:text-lime-100
  dark:data-[highlighted]:data-[state=open]:bg-lime-200
  dark:data-[highlighted]:data-[state=open]:text-lime-950`,

          // OPEN
          `data-[state=open]:bg-lime-200
  data-[state=open]:text-lime-950
  dark:data-[state=open]:bg-lime-800
  dark:data-[state=open]:text-lime-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-lime-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-lime-950`
        ),
        green: cn(
          `text-green-900
  dark:text-green-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-green-900
  data-[highlighted]:text-green-100
  dark:data-[highlighted]:bg-green-200 
  dark:data-[highlighted]:text-green-950`,

          `data-[highlighted]:data-[state=open]:bg-green-900
  data-[highlighted]:data-[state=open]:text-green-100
  dark:data-[highlighted]:data-[state=open]:bg-green-200
  dark:data-[highlighted]:data-[state=open]:text-green-950`,

          // OPEN
          `data-[state=open]:bg-green-200
  data-[state=open]:text-green-950
  dark:data-[state=open]:bg-green-800
  dark:data-[state=open]:text-green-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-green-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-green-950`
        ),
        emerald: cn(
          `text-emerald-900
  dark:text-emerald-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-emerald-900
  data-[highlighted]:text-emerald-100
  dark:data-[highlighted]:bg-emerald-200 
  dark:data-[highlighted]:text-emerald-950`,

          `data-[highlighted]:data-[state=open]:bg-emerald-900
  data-[highlighted]:data-[state=open]:text-emerald-100
  dark:data-[highlighted]:data-[state=open]:bg-emerald-200
  dark:data-[highlighted]:data-[state=open]:text-emerald-950`,

          // OPEN
          `data-[state=open]:bg-emerald-200
  data-[state=open]:text-emerald-950
  dark:data-[state=open]:bg-emerald-800
  dark:data-[state=open]:text-emerald-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-emerald-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-emerald-950`
        ),
        teal: cn(
          `text-teal-900
  dark:text-teal-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-teal-900
  data-[highlighted]:text-teal-100
  dark:data-[highlighted]:bg-teal-200 
  dark:data-[highlighted]:text-teal-950`,

          `data-[highlighted]:data-[state=open]:bg-teal-900
  data-[highlighted]:data-[state=open]:text-teal-100
  dark:data-[highlighted]:data-[state=open]:bg-teal-200
  dark:data-[highlighted]:data-[state=open]:text-teal-950`,

          // OPEN
          `data-[state=open]:bg-teal-200
  data-[state=open]:text-teal-950
  dark:data-[state=open]:bg-teal-800
  dark:data-[state=open]:text-teal-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-teal-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-teal-950`
        ),
        cyan: cn(
          `text-cyan-900
  dark:text-cyan-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-cyan-900
  data-[highlighted]:text-cyan-100
  dark:data-[highlighted]:bg-cyan-200 
  dark:data-[highlighted]:text-cyan-950`,

          `data-[highlighted]:data-[state=open]:bg-cyan-900
  data-[highlighted]:data-[state=open]:text-cyan-100
  dark:data-[highlighted]:data-[state=open]:bg-cyan-200
  dark:data-[highlighted]:data-[state=open]:text-cyan-950`,

          // OPEN
          `data-[state=open]:bg-cyan-200
  data-[state=open]:text-cyan-950
  dark:data-[state=open]:bg-cyan-800
  dark:data-[state=open]:text-cyan-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-cyan-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-cyan-950`
        ),
        sky: cn(
          `text-sky-900
  dark:text-sky-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-sky-900
  data-[highlighted]:text-sky-100
  dark:data-[highlighted]:bg-sky-200 
  dark:data-[highlighted]:text-sky-950`,

          `data-[highlighted]:data-[state=open]:bg-sky-900
  data-[highlighted]:data-[state=open]:text-sky-100
  dark:data-[highlighted]:data-[state=open]:bg-sky-200
  dark:data-[highlighted]:data-[state=open]:text-sky-950`,

          // OPEN
          `data-[state=open]:bg-sky-200
  data-[state=open]:text-sky-950
  dark:data-[state=open]:bg-sky-800
  dark:data-[state=open]:text-sky-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-sky-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-sky-950`
        ),
        blue: cn(
          `text-blue-900
  dark:text-blue-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-blue-900
  data-[highlighted]:text-blue-100
  dark:data-[highlighted]:bg-blue-200 
  dark:data-[highlighted]:text-blue-950`,

          `data-[highlighted]:data-[state=open]:bg-blue-900
  data-[highlighted]:data-[state=open]:text-blue-100
  dark:data-[highlighted]:data-[state=open]:bg-blue-200
  dark:data-[highlighted]:data-[state=open]:text-blue-950`,

          // OPEN
          `data-[state=open]:bg-blue-200
  data-[state=open]:text-blue-950
  dark:data-[state=open]:bg-blue-800
  dark:data-[state=open]:text-blue-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-blue-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-blue-950`
        ),
        indigo: cn(
          `text-indigo-900
  dark:text-indigo-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-indigo-900
  data-[highlighted]:text-indigo-100
  dark:data-[highlighted]:bg-indigo-200 
  dark:data-[highlighted]:text-indigo-950`,

          `data-[highlighted]:data-[state=open]:bg-indigo-900
  data-[highlighted]:data-[state=open]:text-indigo-100
  dark:data-[highlighted]:data-[state=open]:bg-indigo-200
  dark:data-[highlighted]:data-[state=open]:text-indigo-950`,

          // OPEN
          `data-[state=open]:bg-indigo-200
  data-[state=open]:text-indigo-950
  dark:data-[state=open]:bg-indigo-800
  dark:data-[state=open]:text-indigo-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-indigo-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-indigo-950`
        ),
        violet: cn(
          `text-violet-900
  dark:text-violet-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-violet-900
  data-[highlighted]:text-violet-100
  dark:data-[highlighted]:bg-violet-200 
  dark:data-[highlighted]:text-violet-950`,

          `data-[highlighted]:data-[state=open]:bg-violet-900
  data-[highlighted]:data-[state=open]:text-violet-100
  dark:data-[highlighted]:data-[state=open]:bg-violet-200
  dark:data-[highlighted]:data-[state=open]:text-violet-950`,

          // OPEN
          `data-[state=open]:bg-violet-200
  data-[state=open]:text-violet-950
  dark:data-[state=open]:bg-violet-800
  dark:data-[state=open]:text-violet-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-violet-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-violet-950`
        ),
        purple: cn(
          `text-purple-900
  dark:text-purple-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-purple-900
  data-[highlighted]:text-purple-100
  dark:data-[highlighted]:bg-purple-200 
  dark:data-[highlighted]:text-purple-950`,

          `data-[highlighted]:data-[state=open]:bg-purple-900
  data-[highlighted]:data-[state=open]:text-purple-100
  dark:data-[highlighted]:data-[state=open]:bg-purple-200
  dark:data-[highlighted]:data-[state=open]:text-purple-950`,

          // OPEN
          `data-[state=open]:bg-purple-200
  data-[state=open]:text-purple-950
  dark:data-[state=open]:bg-purple-800
  dark:data-[state=open]:text-purple-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-purple-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-purple-950`
        ),
        fuchsia: cn(
          `text-fuchsia-900
  dark:text-fuchsia-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-fuchsia-900
  data-[highlighted]:text-fuchsia-100
  dark:data-[highlighted]:bg-fuchsia-200 
  dark:data-[highlighted]:text-fuchsia-950`,

          `data-[highlighted]:data-[state=open]:bg-fuchsia-900
  data-[highlighted]:data-[state=open]:text-fuchsia-100
  dark:data-[highlighted]:data-[state=open]:bg-fuchsia-200
  dark:data-[highlighted]:data-[state=open]:text-fuchsia-950`,

          // OPEN
          `data-[state=open]:bg-fuchsia-200
  data-[state=open]:text-fuchsia-950
  dark:data-[state=open]:bg-fuchsia-800
  dark:data-[state=open]:text-fuchsia-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-fuchsia-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-fuchsia-950`
        ),
        pink: cn(
          `text-pink-900
  dark:text-pink-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-pink-900
  data-[highlighted]:text-pink-100
  dark:data-[highlighted]:bg-pink-200 
  dark:data-[highlighted]:text-pink-950`,

          `data-[highlighted]:data-[state=open]:bg-pink-900
  data-[highlighted]:data-[state=open]:text-pink-100
  dark:data-[highlighted]:data-[state=open]:bg-pink-200
  dark:data-[highlighted]:data-[state=open]:text-pink-950`,

          // OPEN
          `data-[state=open]:bg-pink-200
  data-[state=open]:text-pink-950
  dark:data-[state=open]:bg-pink-800
  dark:data-[state=open]:text-pink-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-pink-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-pink-950`
        ),
        rose: cn(
          `text-rose-900
  dark:text-rose-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-rose-900
  data-[highlighted]:text-rose-100
  dark:data-[highlighted]:bg-rose-200 
  dark:data-[highlighted]:text-rose-950`,

          `data-[highlighted]:data-[state=open]:bg-rose-900
  data-[highlighted]:data-[state=open]:text-rose-100
  dark:data-[highlighted]:data-[state=open]:bg-rose-200
  dark:data-[highlighted]:data-[state=open]:text-rose-950`,

          // OPEN
          `data-[state=open]:bg-rose-200
  data-[state=open]:text-rose-950
  dark:data-[state=open]:bg-rose-800
  dark:data-[state=open]:text-rose-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-rose-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-rose-950`
        ),
        "white-black": cn(
          `text-neutral-900
  dark:text-neutral-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-neutral-900
  data-[highlighted]:text-neutral-100
  dark:data-[highlighted]:bg-neutral-200 
  dark:data-[highlighted]:text-neutral-950`,

          `data-[highlighted]:data-[state=open]:bg-neutral-900
  data-[highlighted]:data-[state=open]:text-neutral-100
  dark:data-[highlighted]:data-[state=open]:bg-neutral-200
  dark:data-[highlighted]:data-[state=open]:text-neutral-950`,

          // OPEN
          `data-[state=open]:bg-neutral-200
  data-[state=open]:text-neutral-950
  dark:data-[state=open]:bg-neutral-800
  dark:data-[state=open]:text-neutral-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-950`
        ),
        "black-white": cn(
          `text-neutral-900
  dark:text-neutral-100`,

          // HIGHLIGHTED
          `data-[highlighted]:bg-neutral-900
  data-[highlighted]:text-neutral-100
  dark:data-[highlighted]:bg-neutral-200 
  dark:data-[highlighted]:text-neutral-950`,

          `data-[highlighted]:data-[state=open]:bg-neutral-900
  data-[highlighted]:data-[state=open]:text-neutral-100
  dark:data-[highlighted]:data-[state=open]:bg-neutral-200
  dark:data-[highlighted]:data-[state=open]:text-neutral-950`,

          // OPEN
          `data-[state=open]:bg-neutral-200
  data-[state=open]:text-neutral-950
  dark:data-[state=open]:bg-neutral-800
  dark:data-[state=open]:text-neutral-200`,

          // RIGHT SLOT
          `[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-100
  dark:[&_>_[data-role=right-slot]]:data-[highlighted]:text-neutral-950`
        ),
      },
    },
    defaultVariants: {
      color: SUB_TRIGGER,
    },
  }
);

export { subTrigger };
