import { cva } from "class-variance-authority";

import { cn } from "@/lib/cn";
import { ARROW } from "./defaults";

const arrow = cva("", {
  variants: {
    color: {
      slate: cn(
        `fill-slate-300
            dark:fill-slate-700`
      ),
      gray: cn(
        `fill-gray-300
            dark:fill-gray-700`
      ),
      zinc: cn(
        `fill-zinc-300
            dark:fill-zinc-700`
      ),
      neutral: cn(
        `fill-neutral-300
            dark:fill-neutral-700`
      ),
      stone: cn(
        `fill-stone-300
            dark:fill-stone-700`
      ),
      red: cn(
        `fill-red-300
            dark:fill-red-700`
      ),
      orange: cn(
        `fill-orange-300
            dark:fill-orange-700`
      ),
      amber: cn(
        `fill-amber-300
            dark:fill-amber-700`
      ),
      yellow: cn(
        `fill-yellow-300
            dark:fill-yellow-700`
      ),
      lime: cn(
        `fill-lime-300
            dark:fill-lime-700`
      ),
      green: cn(
        `fill-green-300
            dark:fill-green-700`
      ),
      emerald: cn(
        `fill-emerald-300
            dark:fill-emerald-700`
      ),
      teal: cn(
        `fill-teal-300
            dark:fill-teal-700`
      ),
      cyan: cn(
        `fill-cyan-300
            dark:fill-cyan-700`
      ),
      sky: cn(
        `fill-sky-300
            dark:fill-sky-700`
      ),
      blue: cn(
        `fill-blue-300
            dark:fill-blue-700`
      ),
      indigo: cn(
        `fill-indigo-300
            dark:fill-indigo-700`
      ),
      violet: cn(
        `fill-violet-300
            dark:fill-violet-700`
      ),
      purple: cn(
        `fill-purple-300
            dark:fill-purple-700`
      ),
      fuchsia: cn(
        `fill-fuchsia-300
            dark:fill-fuchsia-700`
      ),
      pink: cn(
        `fill-pink-300
            dark:fill-pink-700`
      ),
      rose: cn(
        `fill-rose-300
            dark:fill-rose-700`
      ),
      "white-black": cn(
        `fill-black/40
            dark:fill-white/40`
      ),
      "black-white": cn(
        `fill-white/40
            dark:fill-black/40`
      ),
    },
  },
  defaultVariants: {
    color: ARROW,
  },
});

export { arrow };
