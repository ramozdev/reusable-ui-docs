import { cva } from "class-variance-authority";

import { cn } from "@/lib/cn";
import { LABEL } from "./defaults";

const label = cva(
  `mb-1
  pl-6`,
  {
    variants: {
      color: {
        slate: cn(
          `text-slate-900
            dark:text-slate-100`
        ),
        gray: cn(
          `text-gray-900
            dark:text-gray-100`
        ),
        zinc: cn(
          `text-zinc-900
            dark:text-zinc-100`
        ),
        neutral: cn(
          `text-neutral-900
            dark:text-neutral-100`
        ),
        stone: cn(
          `text-stone-900
            dark:text-stone-100`
        ),
        red: cn(
          `text-red-900
            dark:text-red-100`
        ),
        orange: cn(
          `text-orange-900
            dark:text-orange-100`
        ),
        amber: cn(
          `text-amber-900
            dark:text-amber-100`
        ),
        yellow: cn(
          `text-yellow-900
            dark:text-yellow-100`
        ),
        lime: cn(
          `text-lime-900
            dark:text-lime-100`
        ),
        green: cn(
          `text-green-900
            dark:text-green-100`
        ),
        emerald: cn(
          `text-emerald-900
            dark:text-emerald-100`
        ),
        teal: cn(
          `text-teal-900
            dark:text-teal-100`
        ),
        cyan: cn(
          `text-cyan-900
            dark:text-cyan-100`
        ),
        sky: cn(
          `text-sky-900
            dark:text-sky-100`
        ),
        blue: cn(
          `text-blue-900
            dark:text-blue-100`
        ),
        indigo: cn(
          `text-indigo-900
            dark:text-indigo-100`
        ),
        violet: cn(
          `text-violet-900
            dark:text-violet-100`
        ),
        purple: cn(
          `text-purple-900
            dark:text-purple-100`
        ),
        fuchsia: cn(
          `text-fuchsia-900
            dark:text-fuchsia-100`
        ),
        pink: cn(
          `text-pink-900
            dark:text-pink-100`
        ),
        rose: cn(
          `text-rose-900
            dark:text-rose-100`
        ),
        "white-black": cn(
          `text-black640
            dark:text-white440`
        ),
        "black-white": cn(
          `text-white640
            dark:text-black440`
        ),
      },
    },
    defaultVariants: {
      color: LABEL,
    },
  }
);

export { label };
